public class A extends Object {

	private B _b0;

	public A(B b0) {

		this._b0 = b0;

	}

}
