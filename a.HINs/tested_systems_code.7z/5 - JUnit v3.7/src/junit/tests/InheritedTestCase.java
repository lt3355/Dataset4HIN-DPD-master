package junit.tests;

/**
 * Test class used in SuiteTest
 */
public class InheritedTestCase extends OneTestCase {
	public InheritedTestCase(String name) {
		super(name);
	}
	public void test2() {
	}
}