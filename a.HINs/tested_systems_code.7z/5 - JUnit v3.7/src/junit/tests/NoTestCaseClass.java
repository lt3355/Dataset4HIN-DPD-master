package junit.tests;

/**
 * Test class used in SuiteTest
 */


public class NoTestCaseClass extends Object {
	public NoTestCaseClass(String name) {
	}
	public void testSuccess() {
	}
}