public class B extends Object {

	private C _c0;

	public B() {

		this._c0 = new C();

	}

}
