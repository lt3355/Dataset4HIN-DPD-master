public class C extends Object {


}
