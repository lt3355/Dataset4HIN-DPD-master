import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import spoon.FluentLauncher;
import spoon.IncrementalLauncher;
import spoon.Launcher;
import spoon.MavenLauncher;
import spoon.reflect.CtModel;
import spoon.reflect.declaration.*;

import java.io.File;
import java.util.*;

public class SPOON_Test {
    static final String path = "X:\\code";
    static CtModel model;

    static List<CtClass<?>> classes = new ArrayList<>();
    static List<CtInterface<?>> interfaces = new ArrayList<>();
    static List<CtEnum<?>> enums = new ArrayList<>();
    static List<CtAnnotationType<?>> annotations = new ArrayList<>();

    static Set<CtMethod<?>> methods = new LinkedHashSet<>();
    static Set<? extends CtConstructor<?>> constructors = new LinkedHashSet<>();

    @BeforeClass
    public static void init() {
        // 传目录，可以是模块目录也可以是项目目录
        // 传“多模块项目”的各个模块应当相关，它把各模块看成同一个项目的组成部分，所以不允许各模块相同包下出现同样的类名
        //Launcher launcher = new Launcher();
        //launcher.addInputResource(path);

        // 以字符串形式传入单个java文件
        //CtClass l= Launcher.parseClass("public class A {\n" +
        //        "    B b;\n" +
        //        "    C c;\n" +
        //        "    \n" +
        //        "    public A(B b,C c){\n" +
        //        "        this.b=b;\n" +
        //        "        this.c=c;\n" +
        //        "    }\n" +
        //        "    \n" +
        //        "    A getA(){\n" +
        //        "        A a=new A(new B(),new C());\n" +
        //        "        return a;\n" +
        //        "    }\n" +
        //        "}\n");

        // 适用于类依赖库没有完全添加的情况 some dependencies are unknown
        //launcher.getEnvironment().setNoClasspath(true);

        // 设置目标源码的编译级别
        //launcher.getEnvironment().setComplianceLevel(8);
        //launcher.buildModel();

        // JVM 库和用户库类名冲突时，默认优先 JVM 类，下列这行设置 用户类优先
        //launcher.getEnvironment().setInputClassLoader(customClassloader);


        // CtModel 表示一个 Java 程序
        //model = launcher.getModel();

        model = new FluentLauncher()    // 快速启动器
                .inputResource(path)    // 传目录，可以是模块目录也可以是项目目录
                .complianceLevel(8)     // 设置目标源码的编译级别
                .buildModel();
    }

    @Test
    public void test11(){
        model.getAllTypes().forEach(type->{
            type.getAllFields().forEach(field->{
                System.out.println(field.getFieldDeclaration());
                System.out.println(field.getFieldDeclaration().getPath());
            });
            System.out.println();
        });
    }

    @Test
    public void test_CtModel() {
        System.out.println(model.getRootPackage()); // 返回模块根目录，这里模块的概念来自Java 9
        // 获取所有类、接口、枚举类、注解类
        for (CtType<?> s : model.getAllTypes()) {
            System.out.println("class: " + s.getQualifiedName());

        }
        System.out.println(model.getAllPackages()); // 返回模块下的所有包，包括没有包名的默认包 unnamed package
        System.out.println(model.getUnnamedModule()); // 返回无名模块 unnamed module
        System.out.println(model.getAllModules());    // 返回项目的所有模块，包括无名模块(不含 module-info.java 的模块)
        System.out.println(model.isBuildModelFinished()); // buildModel 之后应当为 true，表示构建成功
    }

    @Test
    @Ignore
    public void test_MavenLauncher() {
        // Maven项目分析器，它会自动从 pom.xml 文件中推断源文件夹列表和依赖项，支持多模块项目分析（项目根目录下必须有pom文件说明模块间包含关系）
        // 可选传入目录 MavenLauncher.SOURCE_TYPE：APP_SOURCE 源码目录 or TEST_SOURCE 测试目录 or ALL_SOURCE 全部
        MavenLauncher launcher = new MavenLauncher(path, MavenLauncher.SOURCE_TYPE.APP_SOURCE);
        launcher.buildModel();
        CtModel md = launcher.getModel();
        for (CtType<?> s : md.getAllTypes()) {
            System.out.println("class: " + s.getQualifiedName());
        }
    }

    @Ignore
    @Test
    public void test_IncrementalLauncher() {
        final File cache = new File("<path_to_cache>");
        Set<File> inputResources = Collections.singleton(new File("<path_to_sources>"));
        Set<String> sourceClasspath = Collections.emptySet(); // Empty classpath

        // 从多个缓存流中加载
        IncrementalLauncher launcher = new IncrementalLauncher(inputResources, sourceClasspath, cache);
        if (launcher.changesPresent()) {
            System.out.println("There are changes since last save to cache.");
        }
        CtModel newModel = launcher.buildModel();
        launcher.saveCache();//更新缓存
    }

    @Test
    @Ignore
    public void test_FluentLauncher() {
        // 允许直接设置大多数选项以实现简单流畅的启动器使用
        CtModel model = new FluentLauncher()
                .inputResource("<path_to_sources>")
                .noClasspath(true)
                .outputDirectory("<path_to_outputdir>")
                //.processor(....)
                .buildModel();

        // 也可以传入具体的Launcher
        /*
        MavenLauncher launcher = new MavenLauncher(....);
        CtModel model2 = new FluentLauncher(launcher)
                .processor(....)
                .encoding(...)
                .buildModel();
         */
    }

    // process 机制只搜索不提供回调，匹配用 query 机制更好
    // CtType 包括：类、接口、枚举类、类型变量
    @BeforeClass
    public static void test_CtType() {
        model.getAllTypes().forEach(ctType -> {
            //System.out.println(ctType.isPrimitive());   // 是基本数据类型？
            //System.out.println(ctType.isArray());     // 是数组？
            //System.out.println(ctType.isGenerics());    // 是类型参数？
            //System.out.println(ctType.isPrimitive());
            if (ctType.isInterface()) {
                interfaces.add((CtInterface<?>) ctType);
            } else if (ctType.isClass()) {
                classes.add((CtClass<?>) ctType);
            } else if (ctType.isEnum()) {
                enums.add((CtEnum<?>) ctType);
            } else if (ctType.isAnnotationType()) {
                annotations.add((CtAnnotationType<?>) ctType);
            }
        });
    }

    @Test
    public void test_CtClass() {
        //classes.forEach(ctClass -> {
        //    System.out.println(ctClass.getQualifiedName());   // 获取全限定名
        //System.out.println(ctClass.getSimpleName());      // 获取简单名
        //System.out.println(ctClass.getModifiers()); // 获取修饰符集合
        //System.out.println(ctClass.getExtendedModifiers()); // 扩展的修饰符集合 implicit
        //System.out.println(ctClass.getVisibility());    // 获取修饰符
        //System.out.println(ctClass.getConstructors());    // 获取构造器（包括无参），也可传入签名列表
        //System.out.println(ctClass.getConstructor());     // 返回接受给定参数类型的类的构造函数
        //System.out.println(ctClass.newInstance());        // 获取类的实例

        // CtTypeReference 要调用 getDeclaration() 才能导航至父类节点
        //System.out.println(ctClass.getSuperclass());    // 获取父类的引用
        //System.out.println(ctClass.getSuperInterfaces());   // 获取实现的接口引用
        //System.out.println(ctClass.isAnonymous());  // 是匿名类？
        //System.out.println(ctClass.isLocalType());  // 是本地类？ 内部类的一种，可以在 方法/lambda 表达式中定义
        //System.out.println(ctClass.getNestedTypes());   // 获取内部类
        //System.out.println(ctClass.getNestedType("xxx"));//根据类名获取内部类
        //System.out.println(ctClass.isParameterized());  // 有类型参数？
        //System.out.println(ctClass.getFormalCtTypeParameters());    // 返回类型变量列表
        //System.out.println(ctClass.isSubtypeOf(xxx)); // 是xxx的子类？

        //System.out.println(ctClass.getUsedTypes(true)); // 获取引用类型（包括同包下的）
        //System.out.println(ctClass.getUsedTypes(false)); // 获取引用类型（不包括同包下的）
        //System.out.println(ctClass.getAllExecutables());    // 获取该类的所有可执行方法：静态方法、实例方法、类方法、构造方法
        //System.out.println(ctClass.getTypeMembers());   // 获取所有子节点（fields, methods, anonymous block...）
        //System.out.println(ctClass.getField("USER"));   // 按字符串获取字段
        //System.out.println(ctClass.getDeclaredField("USER")); // 按字符串获取字段的引用
        //System.out.println(ctClass.getFields());        // 获取所有字段（不含超类）
        //System.out.println(ctClass.getDeclaredFields());    // 获取所有字段的引用（不含超类）
        //System.out.println(ctClass.getDeclaredOrInheritedField("USER"));    // 按名称从此类型及其所有超类获取字段引用
        //System.out.println(ctClass.getAllFields());     // 获取此类型及其所有超类的字段
        //System.out.println(ctClass.getPackage());   // 获取包名，没有则归于 unnamed package
        //System.out.println(ctClass.toStringWithImports());  // 获取源码（包名+代码），所有imports在源码中具化为全限定名
        //System.out.println(ctClass.getReference());   // 获取对应的 CtTypeReference 类型
        //System.out.println(ctClass.isTopLevel());   // 文件的主类型？
        //System.out.println(ctClass.getMethods());      // 获取类的所有方法
        //System.out.println(ctClass.getAllMethods());    // 获取类的实例可调用的所有方法（包括超类、超接口、jdk库方法）！慎用：深递归速度慢
        //System.out.println(ctClass.getMethodsByName("check"));  // 按名称获取方法（包括重载）
        //System.out.println(ctClass.getMethod());  // 按名称 or 按参数列表 or 混合条件 获取方法
        //System.out.println(ctClass.getTypeErasure());   // 返回类型擦除后的类型
        //System.out.println();
        //});
    }

    @Test
    public void test_CtMethod() {
        //System.out.println("<class> " + classes.get(10).getQualifiedName() + "\n");
        methods = classes.get(10).getMethods();
        //methods=classes.get(1).getValueByRole(CtRole.METHOD);

        methods.forEach(method -> {

            //System.out.println(method.getSimpleName());     // 获取方法名
            //System.out.println(method.getSignature());      // 获取方法签名：方法名+(参数...)
            //System.out.println(method.getParameters());     // 获取方法参数
            //System.out.println(method.isOverriding(method));    // 该方法是某方法的重写？自己则返回true
            //System.out.println(method.isDefaultMethod());   // 是默认方法？
            //System.out.println(method.getTopDefinitions()); // 返回定义此方法的层次结构中最顶层的方法(在超类和超接口中)。如果这里是第一次定义，则返回空集合。

            // 犯法参数
            method.getParameters().forEach(parameter -> {
                //System.out.println(parameter.getParent().getSimpleName());  // 获取参数所在的方法
                //System.out.println(parameter.toString());   // 参数类型+参数名
                //System.out.println(parameter.getSimpleName());  // 获取参数名
                //System.out.println(parameter.isInferred());     // 参数是以var命名的lambda参数
                //System.out.println(parameter.isVarArgs());  // 可变参数（必须是最后一个参数）
                //System.out.println(parameter.getPath());        // 返回从模型根到该元素的路径
                //System.out.println(parameter.getPosition());    // (绝对路径):行号

                System.out.println();
            });

            System.out.println();
        });
    }

    @Test
    public void test_CtConstructor() {
        System.out.println("<class> " + classes.get(3).getQualifiedName() + "\n");
        constructors = classes.get(3).getConstructors();
        //constructors=classes.get(3).getValueByRole(CtRole.CONSTRUCTOR);

        constructors.forEach(constructor -> {
            System.out.println(constructor.getSignature());
            System.out.println(constructor.getDeclaringType().getQualifiedName());  // 找到所在的类
            System.out.println();
        });
    }


    // CTLiteral：int x = 4;
    @Test
    public void test_Filter1() {
        System.out.println(classes.get(0).getQualifiedName());
        methods = classes.get(0).getMethods();
        methods.forEach(method -> {
            // 此处可传入任意类型的 CtCodeElement
            //method.getBody().getElements(new TypeFilter<>(CtAbstractInvocation.class)).forEach(i->{
            //    System.out.println(i);
            //    System.out.println(i.getExecutable());
            //    System.out.println(i.getArguments());
            //    CtExpression expression=(CtExpression<?>)i.getArguments().get(0);
            //    System.out.println(expression.getType());
            //    System.out.println();
            //});
            System.out.println(method.toString());

            System.out.println(method.getReference().getDeclaration().toString());
            System.out.println();
        });
    }
}
