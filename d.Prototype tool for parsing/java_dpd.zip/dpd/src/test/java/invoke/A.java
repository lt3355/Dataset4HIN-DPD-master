package invoke;

public class A {
    A(B b) {
    }
}
