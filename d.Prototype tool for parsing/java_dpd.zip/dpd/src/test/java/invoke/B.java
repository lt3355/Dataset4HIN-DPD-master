package invoke;

public class B {
    B(C c, D d) {
    }

    C methodB(A a) {
        return new C();
    }
}
