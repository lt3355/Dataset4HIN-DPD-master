package invoke;

public class C {
    D methodC() {
        return new D();
    }
}
