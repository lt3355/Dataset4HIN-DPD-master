package invoke;

public class D {
    void methodD() {
    }
}
