package invoke;

public class M {
    B b = new B(new C(), new D());

    void methodM() {
        new B(b.methodB(new A(b)), new D()).methodB(new A(b)).methodC().methodD();
    }
}
