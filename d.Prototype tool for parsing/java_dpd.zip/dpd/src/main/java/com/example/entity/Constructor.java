package com.example.entity;

import spoon.reflect.declaration.CtConstructor;

public class Constructor extends Executable {
    public Constructor(CtConstructor<?> constructor) {
        super(constructor);
    }
}
