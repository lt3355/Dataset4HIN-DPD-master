package com.example.entity;

import spoon.reflect.declaration.CtField;

public class Field extends Variable {

    public Field(CtField<?> field) {
        super(field);
    }
}
