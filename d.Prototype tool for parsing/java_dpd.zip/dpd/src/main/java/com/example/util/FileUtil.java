package com.example.util;

import com.alibaba.fastjson2.JSON;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;

/**
 * 文件流工具
 *
 */
public class FileUtil {
    /**
     * 获取目录下的所有文件名
     *
     * @param path 目标目录
     * @return 文件名字符串数组
     */
    public static String[] getFiles(String path) {
        File dir = new File(path);
        List<String> files = new ArrayList<>();
        if (dir.isDirectory()) {
            for (File file : Objects.requireNonNull(dir.listFiles())) {
                files.add(file.getAbsolutePath());
            }
        }
        return files.toArray(String[]::new);
    }

    public static Properties getProperties(String path) throws IOException {
        Properties properties = new Properties();
        properties.load(Objects.requireNonNull(ClassLoader.getSystemResourceAsStream(path)));
        return properties;
    }

    public static void createJsonFile(String content, String filePath) {
        try {
            File file = new File(filePath);
            // 创建上级目录
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            // 如果文件存在，则删除文件
            if (file.exists()) {
                file.delete();
            }
            // 创建文件
            file.createNewFile();
            // 写入文件
            Writer write = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);
            write.write(content);
            write.flush();
            write.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
