package com.example.entity;


import org.jetbrains.annotations.NotNull;
import spoon.reflect.code.CtAssignment;
import spoon.reflect.code.CtFieldRead;
import spoon.reflect.code.CtFieldWrite;
import spoon.reflect.code.CtReturn;
import spoon.reflect.code.CtStatement;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.visitor.filter.TypeFilter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Method extends Executable {

    private String name; // 方法名

    private boolean isGetter; // 该方法检索了所在类的字段

    private boolean isSetter; // 该方法更新了所在类的字段

    private boolean isTopDefinition; // 是顶级定义（没有重写或实现父类方法）

    private boolean isReturnArray; // 返回类型是数组

    public Method(@NotNull CtMethod<?> method) {
        super(method);
        this.name = method.getSimpleName();
        this.isGetter = isGetter(method);
        this.isSetter = isSetter(method);
        this.isTopDefinition = method.getTopDefinitions().isEmpty();
        this.isReturnArray = method.getType().isArray();
    }

    /**
     * getter 定义：没有参数，仅有返回语句，且检索了本类中的字段
     */
    private boolean isGetter(CtMethod<?> method) {
        if (method.getParameters() == null || method.getParameters().size() == 0) {
            if (method.getBody() != null) {
                List<CtStatement> statements = method.getBody().getStatements();
                if (statements != null && statements.size() == 1 && statements.get(0) instanceof CtReturn) {
                    List<CtFieldRead<?>> list = statements.get(0).filterChildren(new TypeFilter<>(CtFieldRead.class)).list();
                    if (list != null && list.size() == 1) {
                        return list.get(0).getVariable().getDeclaringType().getQualifiedName().equals(method.getDeclaringType().getQualifiedName());
                    }
                }
            }
        }
        return false;
    }

    /**
     * setter 定义：有一个参数，仅有赋值语句，且更新了本类中的字段
     */
    private boolean isSetter(CtMethod<?> method) {
        if (method.getParameters() != null && method.getParameters().size() == 1) {
            if (method.getBody() != null) {
                List<CtStatement> statements = method.getBody().getStatements();
                if (statements != null && statements.size() == 1 && statements.get(0) instanceof CtAssignment) {
                    List<CtFieldWrite<?>> list = statements.get(0).filterChildren(new TypeFilter<>(CtFieldWrite.class)).list();
                    if (list != null && list.size() == 1) {
                        return list.get(0).getVariable().getDeclaringType().getQualifiedName().equals(method.getDeclaringType().getQualifiedName());
                    }
                }
            }
        }
        return false;
    }

    public String getName() {
        return name;
    }

    public boolean isGetter() {
        return isGetter;
    }

    public boolean isSetter() {
        return isSetter;
    }

    public boolean isTopDefinition() {
        return isTopDefinition;
    }

    public boolean isReturnArray() {
        return isReturnArray;
    }

    @Override
    public String[] toStringArray() {
        List<String> list = new ArrayList<>(Arrays.asList(super.toStringArray()));
        list.add(name);
        list.add(String.valueOf(isGetter));
        list.add(String.valueOf(isSetter));
        list.add(String.valueOf(isTopDefinition));
        list.add(String.valueOf(isReturnArray));
        return list.toArray(new String[0]);
    }
}