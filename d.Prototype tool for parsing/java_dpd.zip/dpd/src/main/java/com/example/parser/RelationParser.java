package com.example.parser;

import com.example.entity.BaseEntity;
import com.example.entity.Constructor;
import com.example.entity.ConstructorCall;
import com.example.entity.Executable;
import com.example.entity.Field;
import com.example.entity.Invocation;
import com.example.entity.LocalVariable;
import com.example.entity.Method;
import com.example.entity.MethodCall;
import com.example.entity.Parameter;
import com.example.entity.Type;
import com.example.entity.Variable;
import com.example.kind.BlockKind;
import com.example.kind.RelationKind;
import com.example.relation.Relation;
import com.example.util.SpoonUtil;
import spoon.reflect.CtModel;
import spoon.reflect.code.CtAbstractInvocation;
import spoon.reflect.code.CtConstructorCall;
import spoon.reflect.code.CtExpression;
import spoon.reflect.code.CtIf;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.code.CtLocalVariable;
import spoon.reflect.code.CtLoop;
import spoon.reflect.code.CtReturn;
import spoon.reflect.code.CtSwitch;
import spoon.reflect.code.CtTry;
import spoon.reflect.code.CtVariableAccess;
import spoon.reflect.declaration.CtClass;
import spoon.reflect.declaration.CtConstructor;
import spoon.reflect.declaration.CtElement;
import spoon.reflect.declaration.CtExecutable;
import spoon.reflect.declaration.CtField;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.declaration.CtParameter;
import spoon.reflect.declaration.CtType;
import spoon.reflect.declaration.CtVariable;
import spoon.reflect.factory.TypeFactory;
import spoon.reflect.path.CtRole;
import spoon.reflect.reference.CtArrayTypeReference;
import spoon.reflect.reference.CtExecutableReference;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.reference.CtVariableReference;
import spoon.reflect.visitor.filter.TypeFilter;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import static com.example.util.SpoonUtil.isValid;

public class RelationParser {

    private static Set<Relation> relations = new HashSet<>();   // 关系集

    private static RelationParser instance = new RelationParser();  // 关系解析器类的单例

    // 单例必须声明私有构造器
    private RelationParser() {
    }

    // 共有静态单例返回方法
    public static RelationParser getInstance() {
        return instance;
    }

    // 获取关系集
    public Set<Relation> getRelations() {
        return relations;
    }

    // 从关系集中提取节点集
    public Set<BaseEntity> getEntities() {
        Set<BaseEntity> set = new HashSet<>();
        relations.forEach(relation -> {
            set.add(relation.getSource());
            set.add(relation.getTarget());
        });
        return set;
    }

    /**
     * 解析项目模块并记录实体和关系
     *
     * @param ctModel 项目模块对应的 CtModel
     */
    public void parse(CtModel ctModel) {
        Set<CtType<?>> types = new HashSet<>(); // Type集合，用于存储所有 CtType
        ctModel.getAllTypes().forEach(ctType -> { // 遍历 AST 模型中的所有 Type
            types.add(ctType); // 添加正在解析的 Type
            ctType.getUsedTypes(true).forEach(ctTypeReference -> {  // 获取每个 Type 使用到的类并加入集合，包括 jdk 类
                if (!ctTypeReference.isAnonymous()) { // 过滤 CH.ifa.draw.applet.DrawApplet.1 形式
                    CtType<?> ctType1 = ctTypeReference.getTypeDeclaration();
                    if (ctType1 != null) {
                        types.add(ctType1);
                    }
                }
            });
        });
        types.forEach(ctType -> {   // 遍历Type集合
            Type type = new Type(ctType);   // 创建 Type实体
            if (!ctType.isShadow()) { // 对于用到的 jdk 类，仅解析它本身，不解析其继承关系
                if (ctType.getSuperclass() != null) { // 如果有父类，Type集合增加实体的父类，并添加该类与父类的“继承”关系
                    Type super_type = new Type(ctType.getSuperclass().getTypeDeclaration());
                    relations.add(new Relation(type, super_type, RelationKind.INHERITS));
                }
                ctType.getSuperInterfaces().forEach(super_type_reference -> {   // 如果有父接口，同父类的处理方式
                    Type super_type = new Type(super_type_reference.getTypeDeclaration());
                    relations.add(new Relation(type, super_type, RelationKind.INHERITS));
                });
            }
            ctType.getMethods().forEach(ctMethod -> {   // 遍历每个类的方法
                Method method = new Method(ctMethod);   // 创建 Method 实体，并添加“类拥有方法”关系
                relations.add(new Relation(type, method, RelationKind.HAS_METHOD));

                parseOverriding(ctType, ctMethod);  // 解析方法与方法的重写/实现关系

                parseExecutableVariable(method, ctMethod); // 解析方法的参数和局部变量的关联关系

                if (!ctType.isShadow()) { // 对于用到的 jdk 类的方法，不解析其调用详情
                    if (ctMethod.getBody() != null) {
                        int order = 1;
                        for (CtAbstractInvocation<?> ctAbstractInvocation : ctMethod.getBody().getElements(new TypeFilter<>(CtAbstractInvocation.class))) {
                            if (ctAbstractInvocation.getRoleInParent() != CtRole.TARGET && ctAbstractInvocation.getRoleInParent() != CtRole.ARGUMENT) { // 按行判断是否有调用
                                if (ctAbstractInvocation instanceof CtInvocation) { // 寻找所有方法调用
                                    MethodCall methodCall = new MethodCall((CtInvocation<?>) ctAbstractInvocation, order, getBlockKind(ctMethod, ctAbstractInvocation));
                                    relations.add(new Relation(method, methodCall, RelationKind.HAS_INVOKE));
                                    parseNext(methodCall); // 解析同一行潜在的调用链及匿名参数调用
                                } else if (ctAbstractInvocation instanceof CtConstructorCall) { // 寻找所有构造器调用
                                    ConstructorCall constructorCall = new ConstructorCall(ctAbstractInvocation, order, getBlockKind(ctMethod, ctAbstractInvocation));
                                    relations.add(new Relation(method, constructorCall, RelationKind.HAS_INVOKE));
                                    parseNext(constructorCall); // 解析同一行潜在的调用链及匿名参数调用
                                }
                                order++;
                            }
                        }
                    }
                }
                // 解析方法返回类型，如果是数组则脱壳
                CtTypeReference<?> return_ctTypeReference = ctMethod.getType();
                if (isValid(return_ctTypeReference)) {
                    Type return_type = new Type(return_ctTypeReference.getTypeDeclaration());
                    if (return_ctTypeReference.isArray()) {
                        return_type = new Type(((CtArrayTypeReference<?>) return_ctTypeReference).getArrayType().getTypeDeclaration());
                    }
                    relations.add(new Relation(method, return_type, RelationKind.RETURN));
                }
                // 可能存在多个返回语句，每个都是真实返回类型
                List<CtReturn<?>> returns = ctMethod.getElements(new TypeFilter<>(CtReturn.class));
                if (returns != null && !returns.isEmpty()) { // 排除 void 返回
                    for (CtReturn<?> ctReturn : returns) {
                        CtExpression<?> expression = ctReturn.getReturnedExpression();
                        if (expression != null && isValid(expression.getType())) {
                            Type actual_return_type = new Type(expression.getType().getTypeDeclaration());
                            relations.add(new Relation(method, actual_return_type, RelationKind.ACTUAL_RETURN));
                        }
                    }
                }
                // 解析方法抛出的异常
                ctMethod.getThrownTypes().forEach(ctTypeReference -> {
                    Type exception_type = new Type(ctTypeReference.getTypeDeclaration());
                    relations.add(new Relation(method, exception_type, RelationKind.THROWS));
                });
            });
            // 不解析注解类
            if (ctType.isClass() || ctType.isEnum()) {
                ((CtClass<?>) ctType).getConstructors().forEach(ctConstructor -> { // 解析构造器
                    Constructor constructor = new Constructor(ctConstructor);
                    relations.add(new Relation(type, constructor, RelationKind.HAS_CONSTRUCTOR));

                    parseExecutableVariable(constructor, ctConstructor); // 解析构造器的参数和局部变量

                    if (ctConstructor.getBody() != null) { // 解析构造器的调用点
                        int order = 1;
                        for (CtAbstractInvocation<?> ctAbstractInvocation : ctConstructor.getBody().getElements(new TypeFilter<>(CtAbstractInvocation.class))) {
                            if (ctAbstractInvocation.getRoleInParent() != CtRole.TARGET && ctAbstractInvocation.getRoleInParent() != CtRole.ARGUMENT) {
                                if (ctAbstractInvocation instanceof CtInvocation) { // 解析方法调用
                                    if (ctAbstractInvocation.toString().startsWith("super(") || ctAbstractInvocation.toString().startsWith("this(")) {
                                        if (ctConstructor.getBody().toString().contains("super(") || ctConstructor.getBody().toString().contains("this(")) {
                                            parseExistConstructorCall(constructor, ctAbstractInvocation); // 寻找super/this 的目标构造器
                                        }
                                    } else {
                                        MethodCall methodCall = new MethodCall((CtInvocation<?>) ctAbstractInvocation, order, getBlockKind(ctConstructor, ctAbstractInvocation));
                                        relations.add(new Relation(constructor, methodCall, RelationKind.HAS_INVOKE));
                                        parseNext(methodCall);
                                    }
                                } else if (ctAbstractInvocation instanceof CtConstructorCall) { // 解析构造器调用
                                    ConstructorCall constructorCall = new ConstructorCall(ctAbstractInvocation, order, getBlockKind(ctConstructor, ctAbstractInvocation));
                                    relations.add(new Relation(constructor, constructorCall, RelationKind.HAS_INVOKE));
                                    parseNext(constructorCall);
                                }
                                order++;
                            }
                        }
                    }
                    ctConstructor.getThrownTypes().forEach(ctTypeReference -> {
                        Type exception_type = new Type(ctTypeReference.getTypeDeclaration());
                        relations.add(new Relation(constructor, exception_type, RelationKind.THROWS));
                    });
                });
            }
            // getAllFields()方法无法找到内部类的字段
            ctType.filterChildren(new TypeFilter<>(CtField.class)).forEach(field_obj -> { // 解析字段及关联关系，包括内部类的字段
                CtField<?> ctField = (CtField<?>) field_obj;
                Field field = new Field(ctField);
                CtType<?> parent = ((CtField<?>) field_obj).getDeclaringType();
                if (parent.equals(ctType)) {
                    relations.add(new Relation(type, field, RelationKind.HAS_FIELD));
                } else {
                    relations.add(new Relation(new Type(parent), field, RelationKind.HAS_FIELD));
                }
                parseVariableAssociations(field, ctField); // 解析字段关联类型

                CtExpression<?> assignment = ctField.getAssignment(); // 解析初始化语句中的调用点
                Invocation base_invocation = null;
                if (assignment instanceof CtInvocation) {
                    base_invocation = new MethodCall((CtInvocation<?>) assignment, 1, BlockKind.INITIAL);
                } else if (assignment instanceof CtConstructorCall) {
                    base_invocation = new ConstructorCall((CtConstructorCall<?>) assignment, 1, BlockKind.INITIAL);
                }
                if (base_invocation != null) {
                    parseNext(base_invocation);
                    relations.add(new Relation(field, base_invocation, RelationKind.HAS_INITIALIZATION));
                }
            });
        });
    }

    /**
     * 解析调用，包括潜在的调用链及匿名参数调用
     *
     * @param base_invocation 最外层（行级别）的调用
     */
    private void parseNext(Invocation base_invocation) {
        List<CtAbstractInvocation<?>> list = new LinkedList<>();
        list.add((CtAbstractInvocation<?>) base_invocation.getElement());
        base_invocation.getElement().getElements(new TypeFilter<>(CtAbstractInvocation.class)).
                forEach(sub_invocation -> { // 由外到内寻找内部调用
                    if (sub_invocation.getRoleInParent() == CtRole.TARGET) {
                        list.add(sub_invocation);
                    }
                });
        if (list.size() > 1) { // 解析关系要求至少两个调用点实体
            int order = 1;
            int todo_count = list.size(); // 未解析的调用点个数
            while (todo_count > 1) { // 构建调用链
                CtAbstractInvocation<?> first = list.get(list.size() - todo_count);
                todo_count--;
                CtAbstractInvocation<?> second = list.get(list.size() - todo_count);
                Invocation first_invocation = null;
                Invocation second_invocation = null;
                // 解析第一个调用点（外）
                if (first instanceof CtConstructorCall) { // 构造器调用
                    first_invocation = new ConstructorCall(first, order, BlockKind.INITIAL);
                    parseInvocationTarget(first_invocation, first); // 解析目标构造器
                } else if (first instanceof CtInvocation) { // 方法调用
                    first_invocation = new MethodCall((CtInvocation<?>) first, order, BlockKind.INITIAL);
                    parseMethodCaller((MethodCall) first_invocation, (CtInvocation<?>) first); // 解析调用者
                    parseInvocationTarget(first_invocation, first); // 解析目标方法
                }
                // 解析第二个调用点（内）
                if (second instanceof CtConstructorCall) {
                    second_invocation = new ConstructorCall(second, order + 1, BlockKind.INITIAL);
                    parseInvocationTarget(second_invocation, second);
                } else if (second instanceof CtInvocation) {
                    second_invocation = new MethodCall((CtInvocation<?>) second, order + 1, BlockKind.INITIAL);
                    parseMethodCaller((MethodCall) second_invocation, (CtInvocation<?>) second);
                    parseInvocationTarget(second_invocation, second);
                }
                // 两个调用点都解析到了，由外到内建立调用点
                if (first_invocation != null && second_invocation != null) {
                    if (order == 1) { // 如果不是匿名参数调用点
                        parseAnonymousArgument(first_invocation); // 解析该调用点潜在的匿名参数
                    }
                    parseAnonymousArgument(second_invocation);
                    relations.add(new Relation(first_invocation, second_invocation, RelationKind.NEXT));
                }
                order++;
            }
        } else { // 解析最后一个调用点
            parseAnonymousArgument(base_invocation);
            parseInvocationTarget(base_invocation, (CtAbstractInvocation<?>) base_invocation.getElement());
            if (base_invocation instanceof MethodCall) {
                parseMethodCaller((MethodCall) base_invocation, (CtInvocation<?>) base_invocation.getElement());
            }
        }
    }

    /**
     * 解析调用点潜在的匿名参数调用
     *
     * @param base_invocation 当前调用点
     */
    private void parseAnonymousArgument(Invocation base_invocation) {
        List<CtExpression<?>> arguments = ((CtAbstractInvocation<?>) base_invocation.getElement()).getArguments();

        for (int i = 0; i < arguments.size(); i++) {
            CtExpression<?> argument = arguments.get(i);
            Invocation new_invocation = null;
            if (argument instanceof CtInvocation) {
                new_invocation = new MethodCall((CtInvocation<?>) argument, i + 1, BlockKind.ARGUMENT);
            } else if (argument instanceof CtConstructorCall) {
                new_invocation = new ConstructorCall((CtConstructorCall<?>) argument, i + 1, BlockKind.ARGUMENT);
            }
            if (new_invocation != null) {
                parseNext(new_invocation); // 匿名参数调用点也可能存在从它开始的链式调用和匿名调用点
                relations.add(new Relation(base_invocation, new_invocation, RelationKind.HAS_ANONYMOUS_ARGUMENT));
                parseAnonymousArgument(new_invocation); // // 匿名参数调用点也可能存在从它的匿名调用点
            }
        }
    }

    /**
     * 解析方法与方法的重写/实现关系
     *
     * @param ctType   方法所在的类
     * @param ctMethod 当前方法
     */
    private void parseOverriding(CtType<?> ctType, CtMethod<?> ctMethod) {
        if (!ctType.isShadow()) { // 对于用到的 jdk 类，不解析其方法与其父类方法的重写/实现关系
            if (ctMethod.getTopDefinitions() != null) { // 若该方法不是顶级定义（重写或实现了其他方法）
                Set<CtTypeReference<?>> super_references = SpoonUtil.getAllSupers(ctType.getReference()); // 获取所有父类
                for (CtTypeReference<?> super_reference : super_references) {
                    CtType<?> super_ctType = super_reference.getTypeDeclaration();
                    for (CtMethod<?> super_ctMethod : super_ctType.getAllMethods()) {  // 获取所有父类方法
                        if (super_ctMethod.getSignature().equals(ctMethod.getSignature())) {    // 如果方法签名相同
                            Method method = new Method(ctMethod); // 创建方法实体
                            Type super_type = new Type(super_ctType); // 创建父类节点
                            Method super_method = new Method(super_ctMethod);   // 创建父类方法节点，并添加相应关系
                            relations.add(new Relation(super_type, super_method, RelationKind.HAS_METHOD));
                            if (!super_method.getAstPath().equals(method.getAstPath())) {
                                if (super_ctMethod.isAbstract()) {  // 重写和实现取决于父类方法是否是抽象的
                                    relations.add(new Relation(method, super_method, RelationKind.IMPLEMENTS));
                                } else {
                                    relations.add(new Relation(method, super_method, RelationKind.OVERRIDES));
                                }
                            }
                            parseOverriding(super_ctType, super_ctMethod);  // 递归解析父类方法及父类的父类方法的关系
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * 解析变量的关联关系
     *
     * @param variable   变量实体
     * @param ctVariable 变量在 AST 中的表示
     */
    private void parseVariableAssociations(Variable variable, CtVariable<?> ctVariable) {
        CtType<?> associate_ctType = null;
        if (variable.isArray() // 变量是数组，若数组元素不是基本元素也不是数组，则添加变量与元素类的关联关系
                && isValid(((CtArrayTypeReference<?>) ctVariable.getType()).getArrayType())) {
            associate_ctType = ((CtArrayTypeReference<?>) ctVariable.getType()).getArrayType().getTypeDeclaration();
        } else if (variable.isContainer()) { // 变量是容器（非数组）
            ctVariable.getReferencedTypes().forEach(typeReference -> { // 获取变量类型声明的所有类，建立关联关系（与容器类、元素类型都有关系，不管单双列）
                if (!"<nulltype>".equals(typeReference.toString())) {
                    Type associate_type = new Type(typeReference.getTypeDeclaration());
                    relations.add(new Relation(variable, associate_type, RelationKind.ASSOCIATES));
                }
            });
        } else if (isValid(ctVariable.getType())) { // 变量不是基本元素也不是数组，则直接与源类建立关联关系
            associate_ctType = ctVariable.getType().getTypeDeclaration();
        }
        if (associate_ctType != null) {
            Type associate_type = new Type(associate_ctType);
            relations.add(new Relation(variable, associate_type, RelationKind.ASSOCIATES));
        }
    }

    /**
     * 解析可执行体（构造器、方法）的参数和局部变量
     *
     * @param executable   可执行体实体
     * @param ctExecutable 可执行体在 AST 中的表示类
     */
    private void parseExecutableVariable(Executable executable, CtExecutable<?> ctExecutable) {
        List<CtParameter<?>> parameters = ctExecutable.getParameters();
        for (int i = 0; i < parameters.size(); i++) { // 解析参数并编号
            CtParameter<?> ctParameter = parameters.get(i);
            Parameter parameter = new Parameter(ctParameter);
            parameter.setOrder(i + 1);
            relations.add(new Relation(executable, parameter, RelationKind.HAS_PARAMETER));
            parseVariableAssociations(parameter, ctParameter);  // 解析参数变量的关联关系
        }

        if (ctExecutable.getBody() != null) { // 寻找所有局部变量，并解析其关联关系（非必要）
            ctExecutable.getBody().getElements(new TypeFilter<>(CtLocalVariable.class)).forEach(ctLocalVariable -> {
                Variable localVariable = new LocalVariable(ctLocalVariable);
                relations.add(new Relation(executable, localVariable, RelationKind.HAS_LOCAL));
                parseVariableAssociations(localVariable, ctLocalVariable);
            });
        }
    }

    /**
     * 寻找super的目标构造器，范围是已存在的构造器集合
     *
     * @param constructor
     * @param ctAbstractInvocation
     */
    private void parseExistConstructorCall(Constructor constructor, CtAbstractInvocation<?> ctAbstractInvocation) {
        ConstructorCall target_constructorCall = new ConstructorCall(ctAbstractInvocation, 1, BlockKind.CONSTRUCTOR);
        relations.add(new Relation(constructor, target_constructorCall, RelationKind.HAS_INVOKE));
        List<CtExpression<?>> arguments = ctAbstractInvocation.getArguments();
        CtType<?> target_ctType = ((CtConstructor<?>) constructor.getElement()).getDeclaringType();
        if (ctAbstractInvocation.toString().startsWith("super(") && target_ctType.getSuperclass() != null) {
            target_ctType = target_ctType.getSuperclass().getTypeDeclaration();
        }
        for (CtConstructor<?> target_ctConstructor : ((CtClass<?>) target_ctType).getConstructors()) {
            List<CtParameter<?>> parameters = target_ctConstructor.getParameters();
            if (parameters.size() == arguments.size()) {
                boolean flag = true;
                for (int i = 0; i < arguments.size(); i++) {
                    if (!arguments.get(i).getType().isSubtypeOf(parameters.get(i).getType())) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    Constructor target_constructor = new Constructor(target_ctConstructor);
                    relations.add(new Relation(target_constructorCall, target_constructor, RelationKind.TARGET));
                    if (ctAbstractInvocation.toString().startsWith("super(")) {
                        Type super_type = new Type(target_ctType);
                        relations.add(new Relation(super_type, target_constructor, RelationKind.HAS_CONSTRUCTOR));
                    }
                    break;
                }
            }
        }
    }

    /**
     * 获取调用点所在的代码块（循环、选择、异常、返回）
     *
     * @param executable
     * @param invocation
     * @return
     */
    private BlockKind getBlockKind(CtExecutable<?> executable, CtAbstractInvocation<?> invocation) {
        CtElement parent = invocation.getParent();
        while (parent != null
                && !(parent instanceof CtLoop) && !(parent instanceof CtIf)
                && !(parent instanceof CtSwitch) && !(parent instanceof CtTry)
                && !(parent instanceof CtReturn) && !(parent instanceof CtMethod)) {
            parent = parent.getParent();
        }
        if (parent instanceof CtLoop) {
            return BlockKind.LOOP;
        } else if (parent instanceof CtIf || parent instanceof CtSwitch) {
            return BlockKind.CHOOSE;
        } else if (parent instanceof CtTry) {
            return BlockKind.EXCEPTION;
        } else if (parent instanceof CtReturn) {
            return BlockKind.RETURN;
        } else {
            return executable instanceof CtMethod ? BlockKind.METHOD : BlockKind.CONSTRUCTOR;
        }
    }

    /**
     * 解析调用的目标
     *
     * @param invocation
     * @param ctAbstractInvocation
     */
    private void parseInvocationTarget(Invocation invocation, CtAbstractInvocation<?> ctAbstractInvocation) {
        CtExecutableReference<?> target_executable = ctAbstractInvocation.getExecutable();
        if (target_executable.isConstructor()) { // 调用目标是构造器
            Constructor target_constructor = new Constructor((CtConstructor<?>) target_executable.getExecutableDeclaration());
            Type target_type = new Type(((CtConstructor<?>) target_executable.getExecutableDeclaration()).getDeclaringType());
            relations.add(new Relation(target_type, target_constructor, RelationKind.HAS_CONSTRUCTOR));
            relations.add(new Relation(invocation, target_constructor, RelationKind.TARGET));
        } else { // 调用目标是方法
            Method target_method = new Method((CtMethod<?>) target_executable.getExecutableDeclaration());
            Type target_type = new Type(((CtMethod<?>) target_executable.getExecutableDeclaration()).getDeclaringType());
            relations.add(new Relation(target_type, target_method, RelationKind.HAS_METHOD));
            relations.add(new Relation(invocation, target_method, RelationKind.TARGET));
        }
    }

    /**
     * 解析调用发起者
     *
     * @param methodCall
     * @param ctMethodCall
     */
    private void parseMethodCaller(MethodCall methodCall, CtInvocation<?> ctMethodCall) {
        CtExpression<?> ctExpression = ctMethodCall.getTarget(); // 定位方法调用表达式，解析发起者
        if (ctExpression instanceof CtVariableAccess) { // 发起者是变量，过滤链式调用、自己类、可直接调用的jdk类
            CtVariableReference<?> ctVariableReference = ((CtVariableAccess<?>) ctExpression).getVariable();
            CtVariable<?> ctVariable = ctVariableReference.getDeclaration();
            Variable variable = null;
            if (ctVariable == null) { // 无法定位发起者的情况，该情况是来自JDK类的字段，创建目标类和目标字段实体并建立关系
                String field_qualified_name = ctVariableReference.toString();
                if (field_qualified_name.indexOf('.') > 0) {
                    String field_name = field_qualified_name.substring(field_qualified_name.lastIndexOf('.') + 1);
                    String cls_name = field_qualified_name.substring(0, field_qualified_name.lastIndexOf('.'));
                    try {
                        CtType<?> ctType = new TypeFactory().get(Class.forName(cls_name));
                        if (ctType != null) {
                            for (CtField<?> field : ctType.getFields()) {
                                if (field.getSimpleName().equals(field_name)) {
                                    ctVariable = field;
                                    variable = new Field((CtField<?>) ctVariable);
                                    Type type = new Type(ctType);
                                    relations.add(new Relation(type, variable, RelationKind.HAS_FIELD));
                                }
                            }
                        }
                    } catch (ClassNotFoundException ignored) {
                    }
                }
            }
            if (ctVariable instanceof CtParameter) {
                variable = new Parameter((CtParameter<?>) ctVariable);
            } else if (ctVariable instanceof CtLocalVariable) {
                variable = new LocalVariable((CtLocalVariable<?>) ctVariable);
            } else if (ctVariable instanceof CtField) {
                variable = new Field((CtField<?>) ctVariable);
            }
            if (variable != null) {
                relations.add(new Relation(methodCall, variable, RelationKind.CALLER));
            }
        }
    }


}
