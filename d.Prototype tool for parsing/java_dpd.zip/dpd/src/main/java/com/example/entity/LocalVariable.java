package com.example.entity;

import spoon.reflect.code.CtLocalVariable;

public class LocalVariable extends Variable {

    public LocalVariable(CtLocalVariable<?> localVariable) {
        super(localVariable);
    }
}
