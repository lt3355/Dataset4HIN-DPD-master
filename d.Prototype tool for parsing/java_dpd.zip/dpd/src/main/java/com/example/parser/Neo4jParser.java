package com.example.parser;

import com.example.entity.BaseEntity;
import com.example.entity.Executable;
import com.example.entity.Invocation;
import com.example.entity.Method;
import com.example.entity.Parameter;
import com.example.entity.Type;
import com.example.entity.Variable;
import com.example.relation.Relation;
import com.example.util.Neo4jLoader;
import com.example.util.SpoonUtil;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Transaction;

public class Neo4jParser {

    private static GraphDatabaseService service = Neo4jLoader.getService();

    private static Neo4jParser instance = new Neo4jParser();

    private Neo4jParser() {
    }

    public static Neo4jParser getInstance() {
        return instance;
    }

    public void createGraph() {
        RelationParser.getInstance().getEntities().forEach(this::createNode);
        RelationParser.getInstance().getRelations().forEach(this::createRelation);
    }

    private void createRelation(Relation relation) {
        try (Transaction tx = service.beginTx()) {
            Node source = tx.findNode(Label.label(relation.getSource().getEntityType()), "astPath", SpoonUtil.getAstPath(relation.getSource().getElement()));
            Node target = tx.findNode(Label.label(relation.getTarget().getEntityType()), "astPath", SpoonUtil.getAstPath(relation.getTarget().getElement()));
            source.createRelationshipTo(target, relation.getRelationKind());
            tx.commit();
        }
    }

    private void createNode(BaseEntity entity) {
        try (Transaction tx = service.beginTx()) {
            Node node = tx.createNode(Label.label(entity.getEntityType()));
            setProperty(node, "astPath", SpoonUtil.getAstPath(entity.getElement()));
            if (entity instanceof Type) {
                Type type = (Type) entity;
                setProperty(node, "simpleName", type.getSimpleName());
                setProperty(node, "qualifiedName", type.getQualifiedName());
                setProperty(node, "packageName", type.getPackageName());
                setProperty(node, "modifiers", type.getModifiers().toString());
                setProperty(node, "typeKind", type.getTypeKind().toString());
                setProperty(node, "isNested", type.isNested());
                setProperty(node, "isLocalType", type.isLocalType());
                setProperty(node, "isAnonymous", type.isAnonymous());
            } else if (entity instanceof Variable) {
                Variable variable = (Variable) entity;
                setProperty(node, "name", variable.getName());
                setProperty(node, "modifiers", variable.getModifiers());
                setProperty(node, "isContainer", variable.isContainer());
                setProperty(node, "isArray", variable.isArray());
                setProperty(node, "isInitialized", variable.isInitialized());
                if (entity instanceof Parameter) {
                    setProperty(node, "order", ((Parameter) entity).getOrder());
                }
            } else if (entity instanceof Executable) {
                Executable executable = (Executable) entity;
                setProperty(node, "modifiers", executable.getModifiers().toString());
                setProperty(node, "signature", executable.getSignature());
                setProperty(node, "qualifiedSignature", executable.getQualifiedSignature());
                if (entity instanceof Method) {
                    Method method = (Method) entity;
                    setProperty(node, "name", method.getName());
                    setProperty(node, "isGetter", method.isGetter());
                    setProperty(node, "isSetter", method.isSetter());
                    setProperty(node, "isTopDefinition", method.isTopDefinition());
                    setProperty(node, "isReturnArray", method.isReturnArray());
                }
            } else if (entity instanceof Invocation) {
                Invocation invocation = (Invocation) entity;
                setProperty(node, "code", invocation.getCode());
                setProperty(node, "order", invocation.getOrder());
                setProperty(node, "blockKind", invocation.getBlockKind().toString());
            }
            tx.commit();
        }
    }

    private Node setProperty(Node node, String property_name, Object property_obj) {
        node.setProperty(property_name, property_obj == null ? "" : property_obj.toString());
        return node;
    }
}
