package com.example.util;


import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Dom4jUtil {
    public static Map<String, Map<String, Map<String, List<String>>>> parseXmlToMap(String path) throws DocumentException {
        Document document = new SAXReader().read(ClassLoader.getSystemResourceAsStream(path));
        Element root = document.getRootElement();
        List<Element> programs = root.elements();
        Map<String, Map<String, Map<String, List<String>>>> programMap = new HashMap<>();

        programs.forEach(program -> {
            String programName = program.element("name").getText();
            Map<String, Map<String, List<String>>> patternMap = new HashMap<>();
            program.elements("designPattern").forEach(pattern -> {
                String patternName = pattern.attribute("name").getValue().replaceAll(" ", "");
                if (pattern.elementIterator("microArchitectures").hasNext()) {
                    pattern.elementIterator("microArchitectures").next().elements("microArchitecture").forEach(roles -> {
                        if (roles.elementIterator("roles").hasNext()) {
                            roles = roles.elementIterator("roles").next();
                        } else {
                            roles = roles.elementIterator("actors").next();
                        }
                        Map<String, List<String>> roleMap = new HashMap<>();
                        roles.elements().forEach(role -> {
                            String roleName = role.getName();
                            if (role.getName().endsWith("s")) {
                                roleName = roleName.substring(0, roleName.length() - 1);
                            }
                            List<String> roleInstances = new ArrayList<>();
                            role.selectNodes(".//entity").forEach(entity -> {
                                String clsName = entity.getText().trim();
                                if (clsName.length() != 0) {
                                    roleInstances.add(clsName);
                                }
                            });
                            if (!roleInstances.isEmpty()) {
                                if (roleMap.containsKey(roleName)) {
                                    roleInstances.addAll(roleMap.get(roleName));
                                }
                                roleMap.put(roleName, roleInstances);
                            }
                        });
                        patternMap.put(patternName, roleMap);
                    });
                }
            });
            programMap.put(programName, patternMap);
        });
        return programMap;
    }
}
