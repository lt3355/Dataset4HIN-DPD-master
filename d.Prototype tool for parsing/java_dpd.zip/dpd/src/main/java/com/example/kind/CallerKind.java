package com.example.kind;

/**
 * 方法调用类型枚举：
 * 1.通过引用对象调用（调用者为CtVariable）
 * 2.通过匿名对象调用（调用者为CtAbstractInvocation）
 * 3.调用静态类的方法（无调用者）
 * 4.通过this调用自己方法
 * 5.通过super调用父类方法
 *
 */
public enum CallerKind {
    VARIABLE, ANONYMOUS, STATIC, THIS, SUPER
}
