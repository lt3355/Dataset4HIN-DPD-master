package com.example.util;

import com.example.entity.BaseEntity;
import com.example.entity.Constructor;
import com.example.entity.ConstructorCall;
import com.example.entity.Field;
import com.example.entity.LocalVariable;
import com.example.entity.Method;
import com.example.entity.MethodCall;
import com.example.entity.Parameter;
import com.example.entity.Type;
import com.example.relation.Relation;
import com.example.kind.RelationKind;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class OpenCsvUtil {
    private static String directory;
    private static String suffix;
    private static Map<String, CSVWriter> relationWriters = new HashMap<>();

    static {
        try {
            Properties properties = FileUtil.getProperties("neo4j.properties");
            directory = properties.getProperty("OutDirectory") + "/";
            suffix = "." + properties.getProperty("OutFormat");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveGraphAsCsvs(Set<BaseEntity> entities, Set<Relation> relations) throws IOException {
        CSVWriter typeWriter = new CSVWriter(getNotNullFileWriter(directory + "type" + suffix));
        String[] typeHeader = {":LABEL", "astPath:ID", "simpleName", "qualifiedName", "packageName", "modifiers", "typeKind", "isNested", "isLocalType", "isAnonymous"};
        typeWriter.writeNext(typeHeader);

        CSVWriter fieldWriter = new CSVWriter(getNotNullFileWriter(directory + "field" + suffix));
        String[] fieldHeader = {":LABEL", "astPath:ID", "name", "modifiers", "isContainer", "isArray", "isInitialized"};
        fieldWriter.writeNext(fieldHeader);

        CSVWriter parameterWriter = new CSVWriter(getNotNullFileWriter(directory + "parameter" + suffix));
        String[] parameterHeader = {":LABEL", "astPath:ID", "name", "modifiers", "isContainer", "isArray", "isInitialized", "order"};
        parameterWriter.writeNext(parameterHeader);

        CSVWriter localVariableWriter = new CSVWriter(getNotNullFileWriter(directory + "localVariable" + suffix));
        String[] localVariableHeader = {":LABEL", "astPath:ID", "name", "modifiers", "isContainer", "isArray", "isInitialized"};
        localVariableWriter.writeNext(localVariableHeader);

        CSVWriter methodWriter = new CSVWriter(getNotNullFileWriter(directory + "method" + suffix));
        String[] methodHeader = {":LABEL", "astPath:ID", "modifiers", "signature", "qualifiedSignature", "name", "isGetter", "isSetter", "isTopDefinition", "isReturnArray"};
        methodWriter.writeNext(methodHeader);

        CSVWriter constructorWriter = new CSVWriter(getNotNullFileWriter(directory + "constructor" + suffix));
        String[] constructorHeader = {":LABEL", "astPath:ID", "modifiers", "signature", "qualifiedSignature"};
        constructorWriter.writeNext(constructorHeader);

        CSVWriter methodCallWriter = new CSVWriter(getNotNullFileWriter(directory + "methodCall" + suffix));
        String[] methodCallHeader = {":LABEL", "astPath:ID", "code", "order", "blockKind"};
        methodCallWriter.writeNext(methodCallHeader);

        CSVWriter constructorCallWriter = new CSVWriter(getNotNullFileWriter(directory + "constructorCall" + suffix));
        String[] constructorCallHeader = {":LABEL", "astPath:ID", "code", "order", "blockKind"};
        constructorCallWriter.writeNext(constructorCallHeader);

        initRelationWriter("TT");
        initRelationWriter("TF");
        initRelationWriter("TC");
        initRelationWriter("TM");
        initRelationWriter("FT");
        initRelationWriter("FI_c");
        initRelationWriter("FI_m");
        initRelationWriter("PT");
        initRelationWriter("LT");
        initRelationWriter("LI_c");
        initRelationWriter("LI_m");
        initRelationWriter("CT");
        initRelationWriter("CL");
        initRelationWriter("CI_c");
        initRelationWriter("CI_m");
        initRelationWriter("CP");
        initRelationWriter("MI_c");
        initRelationWriter("MI_m");
        initRelationWriter("MT1");
        initRelationWriter("MT2");
        initRelationWriter("MT3");
        initRelationWriter("MP");
        initRelationWriter("ML");
        initRelationWriter("MM1");
        initRelationWriter("MM2");
        initRelationWriter("I_cC");
        initRelationWriter("I_cI_c");
        initRelationWriter("I_cI_m");
        initRelationWriter("I_cI_m1");
        initRelationWriter("I_mI_c");
        initRelationWriter("I_mI_m");
        initRelationWriter("I_mI_m1");
        initRelationWriter("I_mF");
        initRelationWriter("I_mP");
        initRelationWriter("I_mL");
        initRelationWriter("I_mM");
        entities.forEach(entity -> {
            if (entity instanceof Type) {
                typeWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof Field) {
                fieldWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof Parameter) {
                parameterWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof LocalVariable) {
                localVariableWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof Method) {
                methodWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof MethodCall) {
                methodCallWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof Constructor) {
                constructorWriter.writeNext(entity.toStringArray());
            } else if (entity instanceof ConstructorCall) {
                constructorCallWriter.writeNext(entity.toStringArray());
            }
        });
        relations.forEach(relation -> {
            switch (relation.getRelationKind()) {
                case RelationKind.INHERITS:
                    writeRelation(relation, "TT");
                    break;
                case RelationKind.ASSOCIATES:
                    if (relation.getSource() instanceof Field) {
                        writeRelation(relation, "FT");
                    } else if (relation.getSource() instanceof Parameter) {
                        writeRelation(relation, "PT");
                    } else if (relation.getSource() instanceof LocalVariable) {
                        writeRelation(relation, "LT");
                    }
                    break;
                case RelationKind.HAS_METHOD:
                    writeRelation(relation, "TM");
                    break;
                case RelationKind.HAS_FIELD:
                    writeRelation(relation, "TF");
                    break;
                case RelationKind.HAS_CONSTRUCTOR:
                    writeRelation(relation, "TC");
                    break;
                case RelationKind.HAS_LOCAL:
                    if (relation.getSource() instanceof Method) {
                        writeRelation(relation, "ML");
                    } else if (relation.getSource() instanceof Constructor) {
                        writeRelation(relation, "CL");
                    }
                    break;
                case RelationKind.HAS_PARAMETER:
                    if (relation.getSource() instanceof Method) {
                        writeRelation(relation, "MP");
                    } else if (relation.getSource() instanceof Constructor) {
                        writeRelation(relation, "CP");
                    }
                    break;
                case RelationKind.RETURN:
                    writeRelation(relation, "MT2");
                    break;
                case RelationKind.ACTUAL_RETURN:
                    writeRelation(relation, "MT3");
                    break;
                case RelationKind.IMPLEMENTS:
                    writeRelation(relation, "MM2");
                    break;
                case RelationKind.OVERRIDES:
                    writeRelation(relation, "MM1");
                    break;
                case RelationKind.HAS_INVOKE:
                    if (relation.getSource() instanceof Constructor) {
                        if (relation.getTarget() instanceof ConstructorCall) {
                            writeRelation(relation, "CI_c");
                        } else if (relation.getTarget() instanceof MethodCall) {
                            writeRelation(relation, "CI_m");
                        }
                    } else if (relation.getSource() instanceof Method) {
                        if (relation.getTarget() instanceof ConstructorCall) {
                            writeRelation(relation, "MI_c");
                        } else if (relation.getTarget() instanceof MethodCall) {
                            writeRelation(relation, "MI_m");
                        }
                    }
                    break;
                case RelationKind.HAS_INITIALIZATION:
                    if (relation.getSource() instanceof Field) {
                        if (relation.getTarget() instanceof ConstructorCall) {
                            writeRelation(relation, "FI_c");
                        } else if (relation.getTarget() instanceof MethodCall) {
                            writeRelation(relation, "FI_m");
                        }
                    } else if (relation.getSource() instanceof LocalVariable) {
                        if (relation.getTarget() instanceof ConstructorCall) {
                            writeRelation(relation, "LI_c");
                        } else if (relation.getTarget() instanceof MethodCall) {
                            writeRelation(relation, "LI_m");
                        }
                    }
                    break;
                case RelationKind.CALLER:
                    if (relation.getTarget() instanceof Field) {
                        writeRelation(relation, "I_mF");
                    } else if (relation.getTarget() instanceof Parameter) {
                        writeRelation(relation, "I_mP");
                    } else if (relation.getTarget() instanceof LocalVariable) {
                        writeRelation(relation, "I_mL");
                    }
                    break;
                case RelationKind.TARGET:
                    if (relation.getSource() instanceof ConstructorCall) {
                        writeRelation(relation, "I_cC");
                    } else if (relation.getSource() instanceof MethodCall) {
                        writeRelation(relation, "I_mM");
                    }
                    break;
                case RelationKind.NEXT:
                    if (relation.getSource() instanceof ConstructorCall) {
                        writeRelation(relation, "I_cI_m1");
                    } else if (relation.getSource() instanceof MethodCall) {
                        writeRelation(relation, "I_mI_m1");
                    }
                    break;
                case RelationKind.HAS_ANONYMOUS_ARGUMENT:
                    if (relation.getSource() instanceof ConstructorCall) {
                        if (relation.getTarget() instanceof ConstructorCall) {
                            writeRelation(relation, "I_cI_c");
                        } else if (relation.getTarget() instanceof MethodCall) {
                            writeRelation(relation, "I_cI_m");
                        }
                    } else if (relation.getSource() instanceof MethodCall) {
                        if (relation.getTarget() instanceof ConstructorCall) {
                            writeRelation(relation, "I_mI_c");
                        } else if (relation.getTarget() instanceof MethodCall) {
                            writeRelation(relation, "I_mI_m");
                        }
                    }
                    break;
                case RelationKind.THROWS:
                    if (relation.getSource() instanceof Constructor) {
                        writeRelation(relation, "CT");
                    } else if (relation.getSource() instanceof Method) {
                        writeRelation(relation, "MT1");
                    }
                    break;
                default:
                    break;
            }
        });
        typeWriter.close();
        fieldWriter.close();
        parameterWriter.close();
        localVariableWriter.close();
        methodWriter.close();
        methodCallWriter.close();
        constructorWriter.close();
        constructorCallWriter.close();
        for (CSVWriter csvWriter : relationWriters.values()) {
            csvWriter.close();
        }
    }

    private static void initRelationWriter(String relationType) throws IOException {
        String[] relationHeader = {":START_ID", ":TYPE", ":END_ID"};
        CSVWriter relationWriter = new CSVWriter(getNotNullFileWriter(directory + "/relation/" + relationType + suffix));
        relationWriter.writeNext(relationHeader);
        relationWriters.put(relationType, relationWriter);
    }

    private static void writeRelation(Relation relation, String relationType) {
        String[] array = {relation.getSource().getAstPath(), relation.getRelationKind().toString(), relation.getTarget().getAstPath()};
        relationWriters.get(relationType).writeNext(array);
    }

    private static FileWriter getNotNullFileWriter(String path) throws IOException {
        File file = new File(path);
        FileWriter fileWriter;
        if (file.exists()) {
            fileWriter = new FileWriter(path, StandardCharsets.UTF_8);
        } else {
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            file.createNewFile();
            fileWriter = new FileWriter(file, StandardCharsets.UTF_8);
        }
        return fileWriter;
    }
}
