package com.example.entity;

import com.example.util.SpoonUtil;
import spoon.reflect.declaration.CtElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public abstract class BaseEntity implements Serializable {

    private String entityType; // 实体类型

    private CtElement element; // 在抽象语法树中的引用

    private String astPath;

    public BaseEntity(CtElement element) {
        this.entityType = this.getClass().getSimpleName();
        this.element = element;
        this.astPath = SpoonUtil.getAstPath(element);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BaseEntity that = (BaseEntity) o;
        return Objects.equals(astPath, that.astPath);
    }

    @Override
    public int hashCode() {
        return Objects.hash(astPath);
    }

    public String getEntityType() {
        return entityType;
    }

    public CtElement getElement() {
        return element;
    }

    public String getAstPath() {
        return astPath;
    }

    public String[] toStringArray() {
        List<String> list = new ArrayList<>();
        list.add(entityType);
        list.add(astPath);
        return list.toArray(new String[0]);
    }
}