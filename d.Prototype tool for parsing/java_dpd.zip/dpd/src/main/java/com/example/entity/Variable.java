package com.example.entity;

import spoon.reflect.declaration.CtVariable;
import spoon.reflect.declaration.ModifierKind;
import spoon.reflect.factory.TypeFactory;
import spoon.reflect.reference.CtTypeReference;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class Variable extends BaseEntity {
    private String name; // 变量名

    private Set<ModifierKind> modifiers; // 修饰符

    private boolean isContainer; // 是容器，包括数组、单双列集合

    private boolean isArray; // 是数组

    private boolean isInitialized; // 有初始化

    public Variable(CtVariable<?> variable) {
        super(variable);
        this.name = variable.getSimpleName();
        this.modifiers = variable.getModifiers();
        this.isContainer = isContainer(variable.getType());
        this.isArray = variable.getType().isArray();
        this.isInitialized = variable.getDefaultExpression() != null;
    }

    private boolean isContainer(CtTypeReference<?> type) {
        /**
         * 容器类型
         *  数组ARRAY
         *  单列COLLECTION（实现 java.util.Collection 接口）
         *  双列MAP（实现 java.util.Map 接口）
         *  自定义（实现 java.util.Iterator 或 java.util.Enumeration 接口，例：NetworkInterface.getNetworkInterfaces() 返回 Enumeration<NetworkInterface>）
         */
        if (type.isArray()) {
            return true;
        }

        CtTypeReference<?> collection_reference = new TypeFactory().get(Collection.class).getReference();
        CtTypeReference<?> map_reference = new TypeFactory().get(Map.class).getReference();
        CtTypeReference<?> iterator_reference = new TypeFactory().get(Iterator.class).getReference();
        CtTypeReference<?> enumeration_reference = new TypeFactory().get(Enumeration.class).getReference();

        return type.isSubtypeOf(collection_reference)
                || type.isSubtypeOf(map_reference)
                || type.getSuperInterfaces().contains(iterator_reference)
                || type.getSuperInterfaces().contains(enumeration_reference);
    }

    public String getName() {
        return name;
    }

    public Set<ModifierKind> getModifiers() {
        return modifiers;
    }

    public boolean isContainer() {
        return isContainer;
    }

    public boolean isArray() {
        return isArray;
    }

    public boolean isInitialized() {
        return isInitialized;
    }

    @Override
    public String[] toStringArray() {
        List<String> list = new ArrayList<>(Arrays.asList(super.toStringArray()));
        list.add(name);
        list.add(modifiers.toString());
        list.add(String.valueOf(isContainer));
        list.add(String.valueOf(isArray));
        list.add(String.valueOf(isInitialized));
        return list.toArray(new String[0]);
    }
}
