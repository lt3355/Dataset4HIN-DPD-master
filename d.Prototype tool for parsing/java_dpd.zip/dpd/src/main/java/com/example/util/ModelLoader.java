package com.example.util;

import spoon.FluentLauncher;
import spoon.MavenLauncher;
import spoon.reflect.CtModel;

import java.io.File;
import java.io.IOException;

public class ModelLoader {
    /**
     * 普通项目分析器，可手动追加依赖库
     *
     * @param module_dir    项目模块路径
     * @param compile_level 目标源码的编译级别
     * @param libs          需手动添加的依赖库
     * @return CtModel 表示一个项目模块
     */
    public static CtModel getFluentModel(String module_dir, int compile_level, String... libs) throws IOException {
        if (!new File(module_dir).exists()) {
            System.out.println("目录不存在");
            throw new IOException();
        }
        return new FluentLauncher()    // 快速启动器
                .inputResource(module_dir)    // 传目录，可以是模块目录也可以是项目目录
                .complianceLevel(compile_level)     // 设置目标源码的编译级别
                .sourceClassPath(libs)  // 手动添加依赖库：.jar or directory
                .buildModel();
    }

    /**
     * Maven 项目分析器，它会自动从 pom.xml 文件中推断源文件夹列表和依赖项，支持多模块项目分析（项目根目录下必须有pom文件说明模块间包含关系）
     *
     * @param module_dir 项目模块路径
     * @return CtModel 表示一个项目模块
     */
    public static CtModel getMavenModel(String module_dir) {
        // 可选传入目录 MavenLauncher.SOURCE_TYPE：APP_SOURCE 源码目录 or TEST_SOURCE 测试目录 or ALL_SOURCE 全部
        return new MavenLauncher(module_dir, MavenLauncher.SOURCE_TYPE.APP_SOURCE).buildModel();
    }
}
