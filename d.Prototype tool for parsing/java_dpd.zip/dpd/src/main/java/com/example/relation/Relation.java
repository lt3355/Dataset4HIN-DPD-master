package com.example.relation;

import com.example.entity.BaseEntity;
import com.example.kind.RelationKind;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Relation {
    private BaseEntity source;
    private BaseEntity target;
    private RelationKind relationKind;

    public Relation(BaseEntity source, BaseEntity target, RelationKind relationKind) {
        this.source = source;
        this.target = target;
        this.relationKind = relationKind;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Relation relation = (Relation) o;
        return Objects.equals(source, relation.source) &&
                Objects.equals(target, relation.target) &&
                relationKind == relation.relationKind;
    }

    @Override
    public int hashCode() {
        return Objects.hash(source, target, relationKind);
    }

    public BaseEntity getSource() {
        return source;
    }

    public BaseEntity getTarget() {
        return target;
    }

    public RelationKind getRelationKind() {
        return relationKind;
    }

    @Override
    public String toString() {
        return source.toString() + "-[" + relationKind.toString() + "]->" + target.toString() + "\n";
    }

    public String[] toStringArray() {
        List<String> list = new ArrayList<>();
        list.add(source.getAstPath());
        list.add(relationKind.toString());
        list.add(target.getAstPath());
        return list.toArray(new String[0]);
    }
}
