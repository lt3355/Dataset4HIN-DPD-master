package com.example.kind;

import org.neo4j.graphdb.RelationshipType;

/**
 * 关系集枚举
 */
public enum RelationKind implements RelationshipType {
    INHERITS("inherits"), // 继承（类型->类型）
    ASSOCIATES("associates"), // 变量关联类型（变量->类型）
    HAS_METHOD("has_method"), // 类的方法（类型->方法）
    HAS_FIELD("has_field"), // 类的成员变量（类型->字段）
    HAS_CONSTRUCTOR("has_constructor"), // 类的构造器（类型->构造器）
    HAS_LOCAL("has_local"), // 可执行体的本地变量（可执行体-局部变量）
    HAS_PARAMETER("has_parameter"), // 可执行体的参数（可执行体-形参）
    RETURN("return"), // 方法返回类型（方法-类型）
    ACTUAL_RETURN("actual_return"), // 方法实际返回类型（方法-类型）
    IMPLEMENTS("implements"), // 对父类型抽象方法的实现（方法-方法）
    OVERRIDES("overrides"), // 对父类型具体方法的重写（方法-方法）
    HAS_INVOKE("has_invoke"), // 发起调用（可执行体->调用点）
    HAS_INITIALIZATION("has_initialization"), // 变量初始化（变量->调用点）
    CALLER("caller"), // 调用方对象（调用点->变量）
    TARGET("target"), // 被调用方（调用点->可执行体）
    NEXT("next"), // 链式调用的下一个调用点（调用点->调用点）
    HAS_ANONYMOUS_ARGUMENT("has_anonymous_argument"), // 传入的实际参数中的调用点（调用点->调用点）
    THROWS("throws"); // 可执行体抛出的异常（可执行体->类型）

    RelationKind(String lowercase) {
        this.lowercase = lowercase;
    }

    private final String lowercase;

    @Override
    public String toString() {
        return lowercase;
    }
}
