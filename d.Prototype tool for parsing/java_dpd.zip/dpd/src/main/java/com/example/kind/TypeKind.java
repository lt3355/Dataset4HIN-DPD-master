package com.example.kind;

/**
 * 类型的枚举
 */

public enum TypeKind {

    CLASS("class"),

    ENUM("enum"),

    /**
     * 基本数据类型，Java：byte, short, int, long, float, double, char, boolean
     */
    PRIMITIVE("primitive"),

    /**
     * 泛型
     */
    GENERIC("generic");

    TypeKind(String lowercase) {
        this.lowercase = lowercase;
    }

    private final String lowercase;

    @Override
    public String toString() {
        return lowercase;
    }
}
