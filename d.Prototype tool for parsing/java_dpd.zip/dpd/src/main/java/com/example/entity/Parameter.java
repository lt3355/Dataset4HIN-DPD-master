package com.example.entity;

import spoon.reflect.declaration.CtParameter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Parameter extends Variable {
    private int order; // 表示是第几个参数

    public Parameter(CtParameter<?> parameter) {
        super(parameter);
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getOrder() {
        return order;
    }

    @Override
    public String[] toStringArray() {
        List<String> list = new ArrayList<>(Arrays.asList(super.toStringArray()));
        list.add(String.valueOf(order));
        return list.toArray(new String[0]);
    }
}
