package com.example.entity;

import com.example.kind.BlockKind;
import spoon.reflect.code.CtAbstractInvocation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class Invocation extends BaseEntity {

    private String code; // 调用点的代码

    private int order; // 调用的先后顺序

    private BlockKind blockKind; // 所在代码块的类型

    public Invocation(CtAbstractInvocation<?> abstractInvocation, int order, BlockKind blockKind) {
        super(abstractInvocation);
        this.code = abstractInvocation.toString();
        this.order = order;
        this.blockKind = blockKind;
    }

    public String getCode() {
        return code;
    }

    public int getOrder() {
        return order;
    }

    public BlockKind getBlockKind() {
        return blockKind;
    }

    @Override
    public String[] toStringArray() {
        List<String> list = new ArrayList<>(Arrays.asList(super.toStringArray()));
        list.add(code);
        list.add(String.valueOf(order));
        list.add(blockKind.toString());
        return list.toArray(new String[0]);
    }
}