package com.example.entity;

import com.example.kind.TypeKind;
import spoon.reflect.declaration.CtType;
import spoon.reflect.declaration.ModifierKind;
import org.jetbrains.annotations.NotNull;
import spoon.reflect.reference.CtTypeReference;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class Type extends BaseEntity {

    private String simpleName; // 简单名称

    private String qualifiedName; // 全限定名称

    private String packageName; // 所在的包名

    private Set<ModifierKind> modifiers; // 修饰符

    private TypeKind typeKind; // 类型枚举：Class/Interface/Enum/基本数据类型/类型变量

    private boolean isNested; // 是嵌套类

    private boolean isLocalType; // 是可执行体中定义的类

    private boolean isAnonymous; // 是匿名类

    public Type(@NotNull CtType<?> type) {
        super(type);
        this.simpleName = type.getSimpleName();
        this.qualifiedName = type.getQualifiedName();
        if (type.getPackage() != null) {
            this.packageName = type.getPackage().toString();
        }
        this.modifiers = type.getModifiers();
        this.typeKind = getTypeKind(type);
        this.isNested = this.qualifiedName.indexOf('$') > 0;
        this.isLocalType = type.isLocalType();
        this.isAnonymous = type.isAnonymous();
    }

    /**
     * 类型枚举：Class/Interface/Enum/基本数据类型/类型变量
     * Interface 定义：仅有抽象方法的类
     *
     * @param type 判断的目标类型
     * @return 类型枚举
     */
    private TypeKind getTypeKind(CtType<?> type) {
        if (type.isPrimitive()) {
            return TypeKind.PRIMITIVE;
        }
        if (type.isGenerics()) {
            return TypeKind.GENERIC;
        }
        if (type.isEnum()) {
            return TypeKind.ENUM;
        }
        return TypeKind.CLASS;
    }

    private TypeKind getTypeKind(CtTypeReference<?> type) {
        if (type.isPrimitive()) {
            return TypeKind.PRIMITIVE;
        }
        if (type.isGenerics()) {
            return TypeKind.GENERIC;
        }
        if (type.isEnum()) {
            return TypeKind.ENUM;
        }
        return TypeKind.CLASS;
    }

    public String getSimpleName() {
        return simpleName;
    }

    public String getQualifiedName() {
        return qualifiedName;
    }

    public String getPackageName() {
        return packageName;
    }

    public Set<ModifierKind> getModifiers() {
        return modifiers;
    }

    public TypeKind getTypeKind() {
        return typeKind;
    }

    public boolean isNested() {
        return isNested;
    }

    public boolean isLocalType() {
        return isLocalType;
    }

    public boolean isAnonymous() {
        return isAnonymous;
    }

    @Override
    public String[] toStringArray() {
        List<String> list = new ArrayList<>(Arrays.asList(super.toStringArray()));
        list.add(simpleName);
        list.add(qualifiedName);
        list.add(packageName);
        list.add(modifiers.toString());
        list.add(typeKind.toString());
        list.add(String.valueOf(isNested));
        list.add(String.valueOf(isLocalType));
        list.add(String.valueOf(isAnonymous));
        return list.toArray(new String[0]);
    }
}