package com.example.kind;

/**
 * 调用点所在代码块的类型枚举。
 * 这里的代码块指的是可能涉及调用点的语句、方法、构造器、匿名代码块。
 */

public enum BlockKind {

    /**
     * 包括 if、switch 等选择语句
     */
    CHOOSE("choose"),

    /**
     * 包括 for、foreach、while、do 等循环语句
     */
    LOOP("loop"),

    /**
     * 包括 try、catch、finally 等异常处理语句
     */
    EXCEPTION("exception"),

    /**
     * 该调用点作用在某变量的初始化
     */
    INITIAL("initial"),

    /**
     * 作为某调用点的实际参数
     */
    ARGUMENT("argument"),

    /**
     * 该调用点作用在某方法的返回语句
     */
    RETURN("return"),

    /**
     * 如果不在以上所有的代码块，则该调用点直接作用在方法、构造器、匿名代码块
     */
    METHOD("method"),

    CONSTRUCTOR("constructor");

    BlockKind(String lowercase) {
        this.lowercase = lowercase;
    }

    private final String lowercase;

    @Override
    public String toString() {
        return lowercase;
    }
}
