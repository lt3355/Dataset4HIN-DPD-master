package com.example.entity;

import com.example.kind.BlockKind;
import spoon.reflect.code.CtInvocation;

public class MethodCall extends Invocation {

    public MethodCall(CtInvocation<?> methodCall, int order, BlockKind blockKind) {
        super(methodCall, order, blockKind);
    }
}
