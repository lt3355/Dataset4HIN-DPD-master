package com.example.entity;

import com.example.kind.BlockKind;
import spoon.reflect.code.CtAbstractInvocation;

public class ConstructorCall extends Invocation {
    public ConstructorCall(CtAbstractInvocation<?> ctAbstractInvocation, int order, BlockKind blockKind) {
        super(ctAbstractInvocation, order, blockKind);
    }
}
