package com.example.util;

import spoon.reflect.declaration.CtElement;
import spoon.reflect.declaration.CtType;
import spoon.reflect.reference.CtTypeReference;

import java.util.HashSet;
import java.util.Set;

public class SpoonUtil {
    public static String getAstPath(CtElement element) {
        if (element instanceof CtType && ((CtType<?>) element).isAbstract() && ((CtType<?>) element).isFinal()) {
            return ((CtType<?>) element).getQualifiedName();
        }
        return element.getPath().toString();
    }


    /**
     * 验证目标是否合法（不是基本类型、不是数组）
     */
    public static boolean isValid(CtTypeReference<?> reference) {
        if (reference == null) {
            return false;
        }
        if (reference.getTypeDeclaration() == null) {
            return false;
        }
        CtType<?> ctType = reference.getTypeDeclaration();
        // 基本数据类型+数组
        return !(ctType.isAbstract() && ctType.isFinal()) && !"<nulltype>".equals(ctType.toString());
    }

    /**
     * 获取所有父类
     */
    public static Set<CtTypeReference<?>> getAllSuperClasses(CtTypeReference<?> reference) {
        Set<CtTypeReference<?>> supers = new HashSet<>();
        CtTypeReference<?> super_cls = reference.getSuperclass();
        while (super_cls != null) {
            supers.add(super_cls);
            super_cls = super_cls.getSuperclass();
        }
        return supers;
    }

    /**
     * 获取所有父接口
     */
    public static Set<CtTypeReference<?>> getAllSuperInterfaces(CtTypeReference<?> reference) {
        Set<CtTypeReference<?>> supers = new HashSet<>();
        for (CtTypeReference<?> impl : reference.getSuperInterfaces()) {
            supers.add(impl);
            supers.addAll(getAllSuperClasses(impl));
        }
        return supers;
    }

    /**
     * 获取所有父类和父接口
     */
    public static Set<CtTypeReference<?>> getAllSupers(CtTypeReference<?> reference) {
        Set<CtTypeReference<?>> supers = new HashSet<>();
        supers.addAll(getAllSuperClasses(reference));
        supers.addAll(getAllSuperInterfaces(reference));
        return supers;
    }
}
