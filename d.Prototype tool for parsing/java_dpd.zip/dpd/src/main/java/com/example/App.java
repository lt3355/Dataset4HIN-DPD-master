package com.example;

import com.example.parser.Neo4jParser;
import com.example.util.ModelLoader;
import com.example.parser.RelationParser;
import org.neo4j.internal.unsafe.IllegalAccessLoggerSuppressor;

public class App {
    public static void main(String[] args) {
        IllegalAccessLoggerSuppressor.suppress();
        System.out.println("Start parsing...");
        long start = System.currentTimeMillis();
        try {
            RelationParser.getInstance().parse(ModelLoader.getFluentModel("X:\\xx\\invoke", 8));
            //RelationParser.getInstance().parse(ModelLoader.getFluentModel("X:\\xx\\6 - JHotDraw v5.1", 8));
            //RelationParser.getInstance().parse(ModelLoader.getFluentModel("X:\\xx\\5 - JUnit v3.7", 8));
            //RelationParser.getInstance().parse(ModelLoader.getFluentModel("X:\\xx\\1 - QuickUML 2001", 8));
            //RelationParser.getInstance().parse(ModelLoader.getFluentModel("X:\\xx\\2 - Lexi v0.1.1 alpha", 8));
            System.out.println("Parsing finished, cost " + (System.currentTimeMillis() - start) + " ms.");
            System.out.println("-----");
            System.out.println("Start creating the graph database...");
            start = System.currentTimeMillis();
            Neo4jParser.getInstance().createGraph();
            //OpenCsvUtil.saveGraphAsCsvs(RelationParser.getInstance().getEntities(), RelationParser.getInstance().getRelations());
            System.out.println("The graph database has been successfully created, cost " + (System.currentTimeMillis() - start) + " ms.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
