package com.example.entity;

import spoon.reflect.declaration.CtConstructor;
import spoon.reflect.declaration.CtExecutable;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.declaration.ModifierKind;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public abstract class Executable extends BaseEntity {

    private Set<ModifierKind> modifiers; // 修饰符

    private String signature; // 构造器签名/方法签名

    private String qualifiedSignature; // 构造器签名/类型全限定名+方法签名

    public Executable(CtExecutable<?> executable) {
        super(executable);
        this.signature = executable.getSignature();
        if (executable instanceof CtMethod) {
            this.qualifiedSignature = ((CtMethod<?>) executable).getDeclaringType().getQualifiedName() + "." + this.signature;
            this.modifiers = ((CtMethod<?>) executable).getModifiers();
        } else if (executable instanceof CtConstructor) {
            this.qualifiedSignature = this.signature;
            this.modifiers = ((CtConstructor<?>) executable).getModifiers();
        }
    }

    public Set<ModifierKind> getModifiers() {
        return modifiers;
    }

    public String getSignature() {
        return signature;
    }

    public String getQualifiedSignature() {
        return qualifiedSignature;
    }

    @Override
    public String[] toStringArray() {
        List<String> list = new ArrayList<>(Arrays.asList(super.toStringArray()));
        list.add(modifiers.toString());
        list.add(signature);
        list.add(qualifiedSignature);
        return list.toArray(new String[0]);
    }
}