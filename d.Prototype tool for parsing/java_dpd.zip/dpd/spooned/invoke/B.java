package invoke;
public class B {
    B(invoke.C c, invoke.D d) {
    }

    invoke.C methodB(invoke.A a) {
        return new invoke.C();
    }
}