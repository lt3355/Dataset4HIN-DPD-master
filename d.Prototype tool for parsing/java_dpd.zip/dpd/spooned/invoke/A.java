package invoke;
public class A {
    A(invoke.B b) {
    }
}