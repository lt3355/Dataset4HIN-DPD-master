package invoke;
public class C {
    invoke.D methodC() {
        return new invoke.D();
    }
}