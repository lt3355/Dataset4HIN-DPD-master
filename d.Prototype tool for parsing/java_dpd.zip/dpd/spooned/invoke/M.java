package invoke;
public class M {
    invoke.B b = new invoke.B(new invoke.C(), new invoke.D());

    void methodM() {
        new invoke.B(b.methodB(new invoke.A(b)), new invoke.D()).methodB(new invoke.A(b)).methodC().methodD();
    }
}